"use client";
import React, { useMemo, useState } from "react";

export default function RealEstateLanding() {
  const ACCENT = "indigo";

  const COMPANY = {
    name: "Real Estate Solutions",
    phone: "915-313-1093",
    email: "jiacqventures@gmail.com",
    city: "El Paso, TX",
    tagline: {
      en: "Creative real estate solutions that remove friction and unlock options.",
      es: "Soluciones creativas de bienes raíces que eliminan fricción y abren opciones.",
    },
  };

  const [lang, setLang] = useState("en");

  const t = useMemo(() => {
    return lang === "en"
      ? {
          nav: { home: "Home", how: "How We Help", services: "Solutions", contact: "Contact" },
          hero: {
            pre: "Sell, buy, or solve a sticky situation",
            titleStrong: "Real estate, the flexible way.",
            subtitle: COMPANY.tagline.en,
            ctaPrimary: "Get a free options review",
            ctaSecondary: "See how it works",
          },
          trust: { line: "Trusted by local homeowners, buyers & agents across the Borderland" },
          how: {
            title: "How we help people",
            steps: [
              { title: "Quick Discovery Call", text: "We listen to your goals and constraints—payment, timing, repairs, credit, or loan status." },
              { title: "Options Map", text: "We outline multiple paths like Subject-To, Seller Finance, Novation, Cash, or Listing—side by side." },
              { title: "Clear Numbers", text: "We show transparent terms (price, payment, timeline, risk) so you can pick what fits best." },
              { title: "Smooth Close", text: "We coordinate paperwork, escrow, insurance, and title—keeping you informed at every step." },
            ],
          },
          services: {
            title: "Solutions we offer",
            cards: [
              { name: "Subject-To (keep the existing loan)", bullets: [
                "Catch up or maintain payments without new bank financing",
                "Great when equity is tight or rates are low",
                "We manage due-on-sale risk transparently",
              ]},
              { name: "Seller Financing", bullets: [
                "You become the bank—income without landlord headaches",
                "Flexible terms (rate, down, balloon)",
                "Often nets more than a cash sale",
              ]},
              { name: "Cash or Wholetail", bullets: [
                "Fast close and simple paperwork",
                "As‑is condition, no showings",
                "Best for speed and certainty",
              ]},
              { name: "List with a Partner Agent", bullets: [
                "Retail exposure for top‑of‑market offers",
                "Advice on repairs, staging, and timing",
                "You decide if/when to list or switch strategies",
              ]},
            ],
          },
          personas: {
            sellers: { title: "For Homeowners / Sellers", bullets: [
              "Avoid foreclosure or catch up on arrears",
              "Move fast without repairs or showings",
              "Solve escrow/insurance or partial-claim issues",
            ]},
            buyers: { title: "For Buyers / Investors", bullets: [
              "Access homes with flexible financing",
              "Potentially lower upfront costs",
              "Clear amortization and payment schedules",
            ]},
          },
          cta: { title: "See your options in 10 minutes", text: "No pressure. Just clear scenarios tailored to your situation.", button: "Request my options" },
          form: {
            title: "Contact us",
            subtitle: "Tell us a little about your situation and preferred outcome.",
            name: "Full name", phone: "Phone", email: "Email", role: "I am a…",
            roles: ["Homeowner / Seller", "Buyer", "Agent", "Investor"],
            message: "Notes (optional)", submit: "Send",
            privacy: "We respect your privacy. Your info is never shared.",
          },
          footer: { line: `© ${new Date().getFullYear()} ${COMPANY.name} · All rights reserved · ${COMPANY.city}` },
        }
      : {
          nav: { home: "Inicio", how: "Cómo ayudamos", services: "Soluciones", contact: "Contacto" },
          hero: {
            pre: "Vende, compra o resuelve una situación difícil",
            titleStrong: "Bienes raíces, de forma flexible.",
            subtitle: COMPANY.tagline.es,
            ctaPrimary: "Revisión gratuita de opciones",
            ctaSecondary: "Cómo funciona",
          },
          trust: { line: "Confiado por propietarios, compradores y agentes locales en la frontera" },
          how: {
            title: "Cómo ayudamos a las personas",
            steps: [
              { title: "Llamada de Descubrimiento", text: "Escuchamos tus metas y limitaciones—pago, tiempo, reparaciones, crédito o estado del préstamo." },
              { title: "Mapa de Opciones", text: "Trazamos varias rutas como Subject-To, Financiamiento del Vendedor, Novación, Efectivo o Listado—lado a lado." },
              { title: "Números Claros", text: "Mostramos términos transparentes (precio, pago, tiempo, riesgo) para que elijas lo que más te conviene." },
              { title: "Cierre Sencillo", text: "Coordinamos papelería, escrow, seguro y título—manteniéndote informado en cada paso." },
            ],
          },
          services: {
            title: "Soluciones que ofrecemos",
            cards: [
              { name: "Subject-To (conservar el préstamo actual)", bullets: [
                "Ponerse al corriente o mantener pagos sin financiamiento bancario nuevo",
                "Ideal cuando hay poca plusvalía o tasas bajas",
                "Gestionamos el riesgo de due‑on‑sale con transparencia",
              ]},
              { name: "Financiamiento del Vendedor", bullets: [
                "Tú te vuelves el banco—ingreso sin dolores de cabeza de arrendador",
                "Términos flexibles (tasa, enganche, globo)",
                "A menudo deja más que una venta en efectivo",
              ]},
              { name: "Efectivo o Wholetail", bullets: [
                "Cierre rápido y papelería simple",
                "Tal como está, sin exhibiciones",
                "Mejor para rapidez y certeza",
              ]},
              { name: "Listar con un Agente Socio", bullets: [
                "Exposición al mercado retail para ofertas más altas",
                "Asesoría en reparaciones, montaje y tiempos",
                "Tú decides si/cuándo listar o cambiar de estrategia",
              ]},
            ],
          },
          personas: {
            sellers: { title: "Para Propietarios / Vendedores", bullets: [
              "Evita la ejecución hipotecaria o ponte al corriente",
              "Muévete rápido sin reparaciones ni exhibiciones",
              "Resuelve temas de escrow/seguro o reclamaciones parciales",
            ]},
            buyers: { title: "Para Compradores / Inversionistas", bullets: [
              "Accede a casas con financiamiento flexible",
              "Posibles costos iniciales más bajos",
              "Cronogramas y pagos claros",
            ]},
          },
          cta: { title: "Conoce tus opciones en 10 minutos", text: "Sin presión. Solo escenarios claros hechos a tu medida.", button: "Solicitar mis opciones" },
          form: {
            title: "Contáctanos",
            subtitle: "Cuéntanos sobre tu situación y el resultado que prefieres.",
            name: "Nombre completo", phone: "Teléfono", email: "Correo", role: "Soy…",
            roles: ["Propietario / Vendedor", "Comprador", "Agente", "Inversionista"],
            message: "Notas (opcional)", submit: "Enviar",
            privacy: "Respetamos tu privacidad. Nunca compartimos tu información.",
          },
          footer: { line: `© ${new Date().getFullYear()} ${COMPANY.name} · Todos los derechos reservados · ${COMPANY.city}` },
        };
  }, [lang]);

  const ac = (suffix) => `indigo-${suffix}`;

  return (
    <div className="min-h-screen w-full bg-white text-slate-900">
      <header className="sticky top-0 z-40 w-full border-b border-slate-200 bg-white/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            <Logo />
            <div className="flex flex-col leading-tight">
              <span className="text-lg font-bold">{COMPANY.name}</span>
              <span className="text-xs text-slate-500">{COMPANY.city}</span>
            </div>
          </div>
          <nav className="hidden items-center gap-6 md:flex">
            <a href="#home" className="text-sm font-medium hover:text-slate-700">{t.nav.home}</a>
            <a href="#how" className="text-sm font-medium hover:text-slate-700">{t.nav.how}</a>
            <a href="#services" className="text-sm font-medium hover:text-slate-700">{t.nav.services}</a>
            <a href="#contact" className="text-sm font-medium hover:text-slate-700">{t.nav.contact}</a>
          </nav>
          <div className="flex items-center gap-2">
            <LangSwitch lang={lang} setLang={setLang} />
            <a href="#contact" className={`hidden rounded-xl px-4 py-2 text-sm font-semibold text-white md:inline-block bg-${ac("600")} hover:bg-${ac("700")}`}>
              {t.hero.ctaPrimary}
            </a>
          </div>
        </div>
      </header>

      <section id="home" className="relative overflow-hidden">
        <div className={`absolute inset-0 bg-gradient-to-b from-${ac("50")} to-white`} />
        <div className="relative mx-auto grid max-w-7xl grid-cols-1 items-center gap-10 px-4 py-16 md:grid-cols-2 md:py-24">
          <div>
            <div className={`mb-3 inline-flex rounded-full border border-${ac("200")} bg-white px-3 py-1 text-xs font-semibold text-${ac("700")}`}>
              {t.hero.pre}
            </div>
            <h1 className="text-4xl font-extrabold tracking-tight md:text-5xl">{t.hero.titleStrong}</h1>
            <p className="mt-4 max-w-xl text-slate-600">{t.hero.subtitle}</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href="#contact" className={`rounded-xl px-5 py-3 text-sm font-semibold text-white bg-${ac("600")} hover:bg-${ac("700")}`}>{t.hero.ctaPrimary}</a>
              <a href="#how" className={`rounded-xl px-5 py-3 text-sm font-semibold border bg-white hover:bg-${ac("50")} border-${ac("200")} text-${ac("700")}`}>{t.hero.ctaSecondary}</a>
            </div>
            <div className="mt-6 text-sm text-slate-500">{COMPANY.phone} · {COMPANY.email}</div>
          </div>
          <div className="relative">
            <MockCards />
          </div>
        </div>
      </section>

      <section className={`border-y bg-${ac("50")} border-${ac("100")}`}>
        <div className="mx-auto max-w-7xl px-4 py-6 text-center text-sm text-slate-600">{t.trust.line}</div>
      </section>

      <section id="how" className="mx-auto max-w-7xl px-4 py-16 md:py-20">
        <h2 className="text-2xl font-bold md:text-3xl">{t.how.title}</h2>
        <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {t.how.steps.map((s, i) => (
            <div key={i} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <div className={`mb-3 inline-flex h-8 w-8 items-center justify-center rounded-full bg-${ac("100")} text-${ac("700")} font-bold`}>{i + 1}</div>
              <div className="font-semibold">{s.title}</div>
              <p className="mt-2 text-sm text-slate-600">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="services" className={`border-y bg-${ac("50")} border-${ac("100")}`}>
        <div className="mx-auto max-w-7xl px-4 py-16 md:py-20">
          <h2 className="text-2xl font-bold md:text-3xl">{t.services.title}</h2>
          <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {t.services.cards.map((c, i) => (
              <div key={i} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <div className={`mb-2 text-sm font-semibold text-${ac("700")}`}>{c.name}</div>
                <ul className="space-y-2 text-sm text-slate-600">
                  {c.bullets.map((b, k) => (
                    <li key={k} className="flex items-start gap-2">
                      <CheckIcon />
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 md:py-20">
        <div className="grid gap-6 md:grid-cols-2">
          <div className={`rounded-2xl border border-${ac("100")} bg-white p-6 shadow-sm`}>
            <h3 className="text-lg font-semibold">{t.personas.sellers.title}</h3>
            <ul className="mt-3 space-y-2 text-sm text-slate-600">
              {t.personas.sellers.bullets.map((b, i) => (
                <li key={i} className="flex items-start gap-2"><DotIcon /><span>{b}</span></li>
              ))}
            </ul>
          </div>
          <div className={`rounded-2xl border border-${ac("100")} bg-white p-6 shadow-sm`}>
            <h3 className="text-lg font-semibold">{t.personas.buyers.title}</h3>
            <ul className="mt-3 space-y-2 text-sm text-slate-600">
              {t.personas.buyers.bullets.map((b, i) => (
                <li key={i} className="flex items-start gap-2"><DotIcon /><span>{b}</span></li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className={`border-y bg-${ac("50")} border-${ac("100")}`}>
        <div className="mx-auto max-w-7xl px-4 py-14 text-center">
          <h3 className="text-2xl font-bold md:text-3xl">{t.cta.title}</h3>
          <p className="mx-auto mt-2 max-w-2xl text-slate-600">{t.cta.text}</p>
          <a href="#contact" className={`mt-6 inline-block rounded-xl px-6 py-3 text-sm font-semibold text-white bg-${ac("600")} hover:bg-${ac("700")}`}>
            {t.cta.button}
          </a>
        </div>
      </section>

      <section id="contact" className="mx-auto max-w-7xl px-4 py-16 md:py-20">
        <div className="grid gap-8 md:grid-cols-2">
          <div>
            <h2 className="text-2xl font-bold md:text-3xl">{t.form.title}</h2>
            <p className="mt-2 text-slate-600">{t.form.subtitle}</p>
            <div className="mt-6 space-y-3 text-sm text-slate-600">
              <div className="flex items-center gap-2"><PhoneIcon /><span>{COMPANY.phone}</span></div>
              <div className="flex items-center gap-2"><MailIcon /><span>{COMPANY.email}</span></div>
              <div className="flex items-center gap-2"><PinIcon /><span>{COMPANY.city}</span></div>
            </div>
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              const data = new FormData(e.currentTarget);
              const payload = Object.fromEntries(data.entries());
              alert(lang === "en" ? "Thanks! We received your info and will reach out shortly." : "¡Gracias! Recibimos tu información y te contactaremos pronto.");
              console.log("Lead:", payload);
            }}
            className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"
          >
            <div className="grid gap-4 md:grid-cols-2">
              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium">{t.form.name}</label>
                <input name="name" required className="rounded-xl border border-slate-300 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-300" />
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium">{t.form.phone}</label>
                <input name="phone" required className="rounded-xl border border-slate-300 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-300" />
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium">{t.form.email}</label>
                <input name="email" type="email" required className="rounded-xl border border-slate-300 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-300" />
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium">{t.form.role}</label>
                <select name="role" className="rounded-xl border border-slate-300 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-300">
                  {t.form.roles.map((r) => (<option key={r} value={r}>{r}</option>))}
                </select>
              </div>
              <div className="md:col-span-2 flex flex-col gap-1">
                <label className="text-sm font-medium">{t.form.message}</label>
                <textarea name="message" rows={4} className="rounded-xl border border-slate-300 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-300" />
              </div>
            </div>
            <div className="mt-5 flex items-center justify-between">
              <p className="text-xs text-slate-500">{t.form.privacy}</p>
              <button type="submit" className={`rounded-xl px-5 py-2 text-sm font-semibold text-white bg-${ac("600")} hover:bg-${ac("700")}`}>{t.form.submit}</button>
            </div>
          </form>
        </div>
      </section>

      <footer className={`border-t bg-${ac("50")} border-${ac("100")}`}>
        <div className="mx-auto max-w-7xl px-4 py-8 text-center text-xs text-slate-500">{t.footer.line}</div>
      </footer>
    </div>
  );
}

function CheckIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="mt-0.5 h-4 w-4 flex-none">
      <path fillRule="evenodd" d="M2.25 12a9.75 9.75 0 1119.5 0 9.75 9.75 0 01-19.5 0zm14.03-2.28a.75.75 0 10-1.06-1.06l-4.72 4.72-1.72-1.72a.75.75 0 10-1.06 1.06l2.25 2.25c.3.3.77.3 1.06 0l5.25-5.25z" clipRule="evenodd" />
    </svg>
  );
}
function DotIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="mt-1 h-4 w-4 flex-none">
      <circle cx="12" cy="12" r="5" />
    </svg>
  );
}
function PhoneIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="h-5 w-5 flex-none">
      <path d="M2 5a3 3 0 013-3h2a1 1 0 011 1v4a1 1 0 01-.8.98l-1.6.32a13 13 0 006.1 6.1l.32-1.6A1 1 0 0113 12h4a1 1 0 011 1v2a3 3 0 01-3 3h-1C7.82 18 2 12.18 2 5V5z" />
    </svg>
  );
}
function MailIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="h-5 w-5 flex-none">
      <path d="M2 6a2 2 0 012-2h16a2 2 0 012 2v.2l-10 5.6L2 6.2V6zm0 2.38v9.62a2 2 0 002 2h16a2 2 0 002-2V8.38l-9.55 5.35a2 2 0 01-1.9 0L2 8.38z" />
    </svg>
  );
}
function PinIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="h-5 w-5 flex-none">
      <path d="M12 2a7 7 0 00-7 7c0 5.25 7 13 7 13s7-7.75 7-13a7 7 0 00-7-7zm0 9.5a2.5 2.5 0 110-5 2.5 2.5 0 010 5z" />
    </svg>
  );
}
function Logo() {
  return (
    <div className="flex h-10 w-10 items-center justify-center rounded-2xl border border-slate-200 bg-white shadow-sm">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="h-6 w-6 text-slate-800">
        <path d="M3 10.5l9-7 9 7V20a2 2 0 01-2 2h-4v-6H9v6H5a2 2 0 01-2-2v-9.5z" />
      </svg>
    </div>
  );
}

function MockCards() {
  const ac = (s) => `indigo-${s}`;
  return (
    <div className="relative">
      <div className={`absolute -left-10 -top-10 hidden h-64 w-64 rounded-full bg-${ac("100")} blur-2xl md:block`} />
      <div className="grid gap-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs text-slate-500">Average closing timeline</div>
              <div className="text-2xl font-bold">14–30 days</div>
            </div>
            <div className={`rounded-xl bg-${ac("100")} px-3 py-2 text-xs font-semibold text-${ac("700")}`}>Flexible</div>
          </div>
          <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-slate-100">
            <div className={`h-full w-2/3 bg-${ac("500")}`}></div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="text-xs text-slate-500">Seller‑finance deals</div>
            <div className="mt-1 text-2xl font-bold">+10</div>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="text-xs text-slate-500">Subject‑to solutions</div>
            <div className="mt-1 text-2xl font-bold">+12</div>
          </div>
        </div>
        <div className={`rounded-2xl border border-${ac("100")} bg-${ac("50")} p-5 shadow-sm`}>
          <div className="text-xs text-slate-500">Agent partnerships</div>
          <div className={`mt-1 inline-flex items-center gap-2 rounded-xl bg-${ac("100")} px-3 py-1 text-xs font-semibold text-${ac("700")}`}>
            <CheckIcon /> Friendly to agents
          </div>
        </div>
      </div>
    </div>
  );
}

function LangSwitch({ lang, setLang }) {
  return (
    <div className="flex items-center rounded-xl border border-slate-200 bg-white p-1 shadow-sm">
      <button onClick={() => setLang("en")} className={`rounded-lg px-3 py-1 text-xs font-semibold ${lang === "en" ? "bg-slate-900 text-white" : "text-slate-700 hover:bg-slate-100"}`}>
        EN
      </button>
      <button onClick={() => setLang("es")} className={`rounded-lg px-3 py-1 text-xs font-semibold ${lang === "es" ? "bg-slate-900 text-white" : "text-slate-700 hover:bg-slate-100"}`}>
        ES
      </button>
    </div>
  );
}
