import RealEstateLanding from "@/components/RealEstateLanding";

export default function Page() {
  return <RealEstateLanding />;
}
