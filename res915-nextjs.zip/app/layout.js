export const metadata = {
  title: "Real Estate Solutions | RES915",
  description: "Creative real estate solutions in El Paso, TX. Seller Finance, Subject-To, Cash offers, and agent partnerships.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-white text-slate-900">{children}</body>
    </html>
  );
}
