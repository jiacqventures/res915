# RES915 — Real Estate Solutions (Next.js)

This is a Next.js + Tailwind project for **res915.com**.

## Dev
```bash
npm install
npm run dev
```
Then visit http://localhost:3000

## Build & Start
```bash
npm run build
npm start
```

## Deploy
Import this repo into **Vercel** and deploy. Add your domain `res915.com` in the Vercel project settings.
